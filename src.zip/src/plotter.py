import matplotlib.pyplot as plt
import shap
import joblib
import pandas as pd
import numpy as np
from sklearn.metrics import mean_absolute_error
import os
import xgboost as xgb

def plot_metrics(df_agg, features, actual_july, models_dir='../models'):
    """
    Generate plots for model performance metrics and feature importance.
    
    Args:
        df_agg (pd.DataFrame): Preprocessed DataFrame with aggregated user-month data (full).
        features (np.ndarray): Preprocessed feature array (full).
        actual_july (pd.DataFrame): Actual July data with user_id, income, expenses.
        models_dir (str): Directory containing models and holdout data.
    """
    print("Generating metrics and plots...")
    print("Columns in df_agg:", df_agg.columns)
    print(f"Shape of df_agg: {df_agg.shape}")
    print(f"Shape of features: {features.shape}")
    
    # Load holdout data for consistent predictions
    print("Loading holdout data for predictions...")
    try:
        holdout_df = joblib.load(os.path.join(models_dir, 'holdout_df.pkl'))
    except FileNotFoundError:
        print("Error: Holdout file not found. Using full df_agg for predictions.")
        holdout_df = df_agg
    print("Columns in holdout_df:", holdout_df.columns)
    print(f"Shape of holdout_df: {holdout_df.shape}")
    
    # Load scaler for holdout
    try:
        scaler = joblib.load(os.path.join(models_dir, 'scaler.pkl'))
    except FileNotFoundError:
        print("Error: Scaler file not found.")
        raise
    
    # Apply feature engineering to holdout if not already done
    print("Applying feature engineering to holdout data...")
    def user_features(user_df):
        user_df = user_df.sort_values('month')
        user_df['prev_income'] = user_df['income'].shift(1).fillna(0)
        user_df['prev_expenses'] = user_df['expenses'].shift(1).fillna(0)
        user_df['income_trend'] = (user_df['income'] - user_df['prev_income']) / (user_df['prev_income'] + 1e-6)
        user_df['expenses_trend'] = (user_df['expenses'] - user_df['prev_expenses']) / (user_df['prev_expenses'] + 1e-6)
        # Load fixed categories from training
        try:
            train_num_cols = joblib.load(os.path.join(models_dir, 'feature_columns.pkl'))
            fixed_categories = [col.replace('avg_exp_', '') for col in train_num_cols if col.startswith('avg_exp_')]
        except FileNotFoundError:
            print("Warning: feature_columns.pkl not found. Using categories from first row.")
            fixed_categories = list(user_df['expenses_breakdown'].iloc[0].keys())
        for cat in fixed_categories:
            user_df[f'avg_exp_{cat}'] = user_df['expenses_breakdown'].apply(lambda d: d.get(cat, 0)).rolling(3).mean().fillna(0)
        return user_df
    holdout_df = holdout_df.groupby('user_id').apply(user_features, include_groups=True).reset_index(drop=True)
    
    # Scale holdout features
    num_cols = [col for col in holdout_df.columns if col.startswith('prev_') or col.startswith('trend_') or col.startswith('avg_')]
    holdout_features = scaler.transform(holdout_df[num_cols])
    print(f"Shape of holdout_features: {holdout_features.shape}")
    
    # Load models (using income models for demo)
    print("Loading models for metrics...")
    models = {}
    for c in range(5):
        try:
            models[c] = joblib.load(os.path.join(models_dir, f'xgb_income_cluster_{c}.pkl'))
            print(f"Loaded income model for cluster {c}")
        except FileNotFoundError:
            print(f"Warning: Income model for cluster {c} not found. Skipping.")
    
    # Generate predictions from holdout
    print("Generating predictions for evaluation...")
    predictions = []
    for cluster in holdout_df['cluster'].unique():
        if cluster not in models:
            print(f"Warning: No model for cluster {cluster}. Skipping.")
            continue
        cluster_df = holdout_df[holdout_df['cluster'] == cluster].copy()
        cluster_idx = cluster_df.index
        if len(cluster_df) == 0:
            print(f"Warning: No data for cluster {cluster}. Skipping.")
            continue
        pred_income = models[cluster].predict(holdout_features[cluster_idx])
        cluster_df.loc[:, 'predicted_income'] = pred_income  # Use .loc to avoid SettingWithCopyWarning
        predictions.append(cluster_df[['user_id', 'predicted_income']])
    if not predictions:
        print("Error: No predictions generated. Check models and data.")
        return
    pred_df = pd.concat(predictions)
    print(f"Shape of pred_df: {pred_df.shape}")
    
    # Merge with actual July data
    merged = actual_july.merge(pred_df, on='user_id', how='inner')
    print(f"Merged data shape for evaluation: {merged.shape}")
    
    # Add cluster to merged for metrics
    merged = merged.merge(holdout_df[['user_id', 'cluster']], on='user_id', how='left')
    
    # Calculate metrics
    metrics = []
    if len(merged) > 0:
        for cluster in merged['cluster'].unique():
            cluster_data = merged[merged['cluster'] == cluster]
            if len(cluster_data) > 0:
                mae = mean_absolute_error(cluster_data['income'], cluster_data['predicted_income'])
                metrics.append({'Cluster': cluster, 'MAE_Income': mae})
    else:
        print("Warning: No merged data for evaluation. Using dummy metrics.")
        metrics = [{'Cluster': 0, 'MAE_Income': np.nan}]
    metrics_df = pd.DataFrame(metrics)
    print("Metrics per cluster:")
    print(metrics_df)
    
    # Bar plot for metrics (skip if empty)
    if len(metrics_df) > 0 and not metrics_df.empty:
        metrics_df.plot(x='Cluster', y='MAE_Income', kind='bar', figsize=(10, 6))
        plt.title('MAE Income per Cluster')
        os.makedirs('../img', exist_ok=True)
        plt.savefig('../img/cluster_metrics.png')
        plt.close()
    else:
        print("Skipping cluster metrics plot due to empty data.")
    
    # SHAP Global
    print("Generating SHAP summary plot...")
    if len(models) > 0:
        explainer = shap.TreeExplainer(list(models.values())[0])
        sample_size = min(500, len(holdout_features))
        shap_values = explainer.shap_values(holdout_features[:sample_size])  # Sample for speed
        try:
            # Load feature names
            train_num_cols = joblib.load(os.path.join(models_dir, 'feature_columns.pkl'))
            shap.summary_plot(shap_values, holdout_features[:sample_size], feature_names=train_num_cols, show=False)
            plt.savefig('../img/shap_summary.png')
            plt.close()
        except FileNotFoundError:
            print("Warning: feature_columns.pkl not found. Skipping feature names for SHAP.")
            shap.summary_plot(shap_values, holdout_features[:sample_size], show=False)
            plt.savefig('../img/shap_summary.png')
            plt.close()
    else:
        print("Skipping SHAP plot due to no models.")
    
    # XGBoost Built-in (Gain)
    print("Generating XGBoost feature importance plot...")
    if len(models) > 0:
        xgb.plot_importance(list(models.values())[0], max_num_features=20)
        plt.title('XGBoost Feature Importance (Gain)')
        plt.savefig('../img/xgb_importance.png')
        plt.close()
    else:
        print("Skipping XGBoost importance plot due to no models.")
    
    # Permutation Importance
    print("Generating permutation importance plot...")
    if len(merged) > 0 and len(models) > 0:
        sample_size = min(500, len(holdout_features), len(merged))
        perm = permutation_importance(list(models.values())[0], holdout_features[:sample_size], merged['income'][:sample_size], n_repeats=10, random_state=42)
        try:
            train_num_cols = joblib.load(os.path.join(models_dir, 'feature_columns.pkl'))
            perm_df = pd.DataFrame({'feature': train_num_cols, 'importance': perm.importances_mean})
        except FileNotFoundError:
            print("Warning: feature_columns.pkl not found. Using generic feature names.")
            perm_df = pd.DataFrame({'feature': [f'feature_{i}' for i in range(len(perm.importances_mean))], 'importance': perm.importances_mean})
        perm_df.sort_values('importance', ascending=False).head(20).plot(kind='bar', x='feature', y='importance')
        plt.title('Permutation Importance')
        plt.savefig('../img/permutation_importance.png')
        plt.close()
    else:
        print("Skipping permutation importance plot due to no data or models.")
    print("All plots saved to ../img/")